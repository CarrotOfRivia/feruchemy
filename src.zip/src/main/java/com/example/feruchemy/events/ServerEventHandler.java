package com.example.feruchemy.events;


import com.example.feruchemy.Feruchemy;
import com.example.feruchemy.caps.FeruchemyCapability;
import com.example.feruchemy.config.Config;
import com.example.feruchemy.effects.EffectRegister;
import com.example.feruchemy.network.NetworkUtil;
import com.legobmw99.allomancy.modules.materials.MaterialsSetup;
import com.legobmw99.allomancy.modules.powers.PowersConfig;
import com.legobmw99.allomancy.modules.powers.util.AllomancyCapability;
import com.legobmw99.allomancy.network.Network;
import com.legobmw99.allomancy.setup.Metal;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.GameRules;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.SleepingTimeCheckEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Feruchemy.MOD_ID, value = Dist.DEDICATED_SERVER)
public class ServerEventHandler {

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event){
        PlayerEntity player = event.getPlayer();
        if(! player.world.isRemote()){
            EffectInstance effect = player.getActivePotionEffect(EffectRegister.FIRE_ASPECT.get());
            if(effect != null){
                event.getTarget().setFire(3);
            }

            EffectInstance effect1 = player.getActivePotionEffect(EffectRegister.KNOCK_BACK.get());
            if(effect1 != null && event.getTarget() instanceof LivingEntity){
                int level = effect1.getAmplifier()+1;
                ((LivingEntity)event.getTarget()).applyKnockback(level * 0.5F, (double) MathHelper.sin(player.rotationYaw * ((float)Math.PI / 180F)), (double)(-MathHelper.cos(player.rotationYaw * ((float)Math.PI / 180F))));
            }
        }
    }

    @SubscribeEvent
    public void onSleepingTimeCheck(SleepingTimeCheckEvent event){
        PlayerEntity player = event.getPlayer();
        if(! player.world.isRemote()){
            EffectInstance effect = player.getActivePotionEffect(EffectRegister.BED_USE.get());
            if(effect != null){
                event.setResult(Event.Result.ALLOW);
            }
        }
    }

    @SubscribeEvent
    public void onLivingHeal(LivingHealEvent event){

    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event){
        if(! event.player.world.isRemote()){
            NetworkUtil.sync(event.player);
            EffectInstance effect = event.player.getActivePotionEffect(EffectRegister.NON_GENERATION.get());
            if(effect!=null){
                if(event.player.getHealth()>event.player.getMaxHealth()-7){
                    event.player.setHealth(event.player.getMaxHealth()-7);
                }
            }
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.getPlayer().world.isRemote()) {
            PlayerEntity player = event.getPlayer();
            FeruchemyCapability cap = FeruchemyCapability.forPlayer(player);
            PlayerEntity oldPlayer = event.getOriginal();
            oldPlayer.getCapability(FeruchemyCapability.FERUCHEMY_CAP).ifPresent((oldCap) -> {
                cap.setDeathLoc(oldCap.getDeathLoc(), oldCap.getDeathDim());
                Metal[] metals;
                int len;
                int i;
                Metal mt;

                if (true) {
                    metals = Metal.values();
                    len = metals.length;

                    for(i = 0; i < len; ++i) {
                        mt = metals[i];
                        if(oldCap.hasPower(mt)){
                            cap.addPower(mt);
                        }
                    }
                    cap.setFid(oldCap.getFid());
                    cap.setStoredExp(oldCap.getStoredExp());

                }

            });
            Network.sync(player);
        }
    }

    @SubscribeEvent
    public void onJoinWorld(PlayerEvent.PlayerLoggedInEvent event) {
        if (!event.getPlayer().world.isRemote && event.getPlayer() instanceof ServerPlayerEntity) {
            ServerPlayerEntity player = (ServerPlayerEntity)event.getPlayer();
            FeruchemyCapability cap = FeruchemyCapability.forPlayer(player);
            if (Config.STARTING_POWER.get()==0 && cap.isUninvested()) {
                byte randomMisting = (byte)((int)(Math.random() * (double)Metal.values().length));
                cap.addPower(Metal.getMetal(randomMisting));
                ItemStack flakes = new ItemStack((IItemProvider)((RegistryObject) MaterialsSetup.FLAKES.get(randomMisting)).get());
                if (!player.inventory.addItemStackToInventory(flakes)) {
                    ItemEntity entity = new ItemEntity(player.getEntityWorld(), player.getPositionVec().getX(), player.getPositionVec().getY(), player.getPositionVec().getZ(), flakes);
                    player.getEntityWorld().addEntity(entity);
                }
            }

            Network.sync(event.getPlayer());
        }

    }

}

