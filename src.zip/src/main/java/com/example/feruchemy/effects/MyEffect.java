package com.example.feruchemy.effects;

import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectType;

public class MyEffect extends Effect {
    public MyEffect(EffectType typeIn, int liquidColorIn) {
        super(typeIn, liquidColorIn);
    }
}
