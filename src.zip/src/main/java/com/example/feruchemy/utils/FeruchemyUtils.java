package com.example.feruchemy.utils;

import com.example.feruchemy.caps.FeruchemyCapability;
import com.example.feruchemy.items.MetalMind;
import com.legobmw99.allomancy.modules.materials.MaterialsSetup;
import com.legobmw99.allomancy.modules.powers.PowersConfig;
import com.legobmw99.allomancy.modules.powers.util.AllomancyCapability;
import com.legobmw99.allomancy.setup.Metal;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.MainWindow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.renderer.texture.Texture;
import net.minecraft.command.CommandSource;
import net.minecraft.command.ICommandSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.client.gui.ForgeIngameGui;
import net.minecraftforge.fml.RegistryObject;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class FeruchemyUtils {
    public static final List<Item> FLAKE_ITEMS = new ArrayList<>();
    static {
        for (int i=0; i<Metal.values().length; i++){
            FLAKE_ITEMS.add(MaterialsSetup.FLAKES.get(i).get());
        }
    }

    public static ItemStack getMetalMindStack(PlayerEntity player){
        for(int i=0; i<9; i++){
            ItemStack stack = player.inventory.getStackInSlot(i);
            if(stack.getItem() instanceof MetalMind){
                return stack;
            }
        }
        return null;
    }

    public static boolean canPlayerTap(PlayerEntity playerEntity, ItemStack itemStack, Metal metal){
        FeruchemyCapability capability = FeruchemyCapability.forPlayer(playerEntity);

        int playerFid = capability.getFid();
        int itemFid = MetalMind.getFid(itemStack);

        boolean condition = FeruchemyCapability.canPlayerUse(playerEntity, metal);

        return condition && ((playerFid == itemFid) || (itemFid == 0));
    }


    public static boolean canPlayerStore(PlayerEntity playerEntity, ItemStack itemStack, Metal metal){
        FeruchemyCapability capability = FeruchemyCapability.forPlayer(playerEntity);

        int playerFid = capability.getFid();
        int itemFid = MetalMind.getFid(itemStack);

        MetalMind.Status statusAluminum = MetalMind.getStatus(itemStack, Metal.ALUMINUM);
        boolean condition1 = (itemFid == 0) && ((metal==Metal.ALUMINUM) || (statusAluminum== MetalMind.Status.STORING));

        MetalMind.Status status = MetalMind.getStatus(itemStack, metal);
        boolean condition2 = (status == MetalMind.Status.TAPPING || status == MetalMind.Status.STORING);

        boolean condition3 = FeruchemyCapability.canPlayerUse(playerEntity, metal);

        return condition3 && ((playerFid == itemFid) || condition1 || (itemFid == -1) || condition2);
    }

    public static void whenEnd(PlayerEntity playerEntity, ItemStack itemStack, Metal metal, MetalMind.Status status){
        if(status == MetalMind.Status.TAPPING){
            whenTappingEnd(playerEntity, itemStack, metal);
        }
        else if(status == MetalMind.Status.STORING){
            whenStoringEnd(playerEntity, itemStack, metal);
        }
    }


    public static void whenStoringEnd(PlayerEntity playerEntity, ItemStack itemStack, Metal metal){
        // called when storing/tapping ends
        if(! playerEntity.world.isRemote()){
            if(metal == Metal.TIN){
                EffectInstance effectInstance = playerEntity.getActivePotionEffect(Effects.BLINDNESS);
                if(effectInstance!=null && effectInstance.getDuration() <= 3*MetalMind.CD){
                    playerEntity.removePotionEffect(Effects.BLINDNESS);
                }
            }
            else if(metal == Metal.ZINC){
                ServerWorld world = (ServerWorld) playerEntity.world;
                world.getServer().getCommandManager().handleCommand(new CommandSource(ICommandSource.DUMMY, playerEntity.getPositionVec(), Vector2f.ZERO, world, 2, "null", new StringTextComponent(""), world.getServer(), null),
                        "/gamerule randomTickSpeed 3");
            }
        }
    }

    public static void whenTappingEnd(PlayerEntity playerEntity, ItemStack itemStack, Metal metal) {
        // called when storing/tapping ends
        if (!playerEntity.world.isRemote()) {
            if(metal == Metal.TIN){
                EffectInstance effectInstance = playerEntity.getActivePotionEffect(Effects.NIGHT_VISION);
                if(effectInstance!=null && effectInstance.getDuration() <= 210+MetalMind.CD){
                    playerEntity.removePotionEffect(Effects.NIGHT_VISION);
                }
            }
            else if(metal == Metal.ZINC){
                ServerWorld world = (ServerWorld) playerEntity.world;
                world.getServer().getCommandManager().handleCommand(new CommandSource(ICommandSource.DUMMY, playerEntity.getPositionVec(), Vector2f.ZERO, world, 2, "null", new StringTextComponent(""), world.getServer(), null),
                        "/gamerule doDaylightCycle true");
            }
        }
    }


}
