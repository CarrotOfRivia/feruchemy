package com.example.feruchemy.config;

import com.example.feruchemy.items.MetalMind;
import com.legobmw99.allomancy.setup.Metal;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.HashMap;

public class Config {
    public static ForgeConfigSpec COMMON;

    public static final HashMap<Metal, ForgeConfigSpec.IntValue> STORAGE = new HashMap<>();

    public static final ForgeConfigSpec.IntValue STARTING_POWER;

    static {
        ForgeConfigSpec.Builder CONFIG_BUILDER = new ForgeConfigSpec.Builder();

        for (Metal metal: Metal.values()){
            int defaultVal;
            if(metal == Metal.COPPER){
                defaultVal = 25;
            }
            else {
                defaultVal = 10;
            }
            STORAGE.put(metal, CONFIG_BUILDER.defineInRange("multiplier_"+metal.toString().toLowerCase(), defaultVal, 0, 100));
        }

        STARTING_POWER = CONFIG_BUILDER.comment("1: all feruchemy; 0: consistent with allomancy").defineInRange("starting_power", 0, 0, 1);

        COMMON = CONFIG_BUILDER.build();
    }
}
